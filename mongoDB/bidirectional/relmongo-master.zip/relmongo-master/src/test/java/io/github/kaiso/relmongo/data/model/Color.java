package io.github.kaiso.relmongo.data.model;

public enum Color {
   BLUE,RED
}
