package com.jay.demo.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.jay.demo.dao.UserDao;
import com.jay.demo.dao.model.User;
import com.jay.demo.enums.ResponseCode;
import com.jay.demo.exceptions.ApException;
import com.jay.demo.response.CommonResponse;
import com.jay.demo.service.UserService;
import com.jay.demo.util.JsonUtil;

@Service
public class UserServiceImp implements UserService{

	@Autowired
	UserDao dao;
	
	@Override
	public CommonResponse findAll() throws ApException {
		List<User> users = dao.findAll();
		users=null;
		if(users==null) {
			throw new ApException(ResponseCode.RECORD_NOT_FOUND.getHttpCode(),ResponseCode.RECORD_NOT_FOUND.getDesc(), new NullPointerException(),ResponseCode.RECORD_NOT_FOUND.getCode());
		}
		@SuppressWarnings("unused")
		List<User> jsonUsers = JsonUtil.fromObject(users, new TypeReference<List<User>>(){});
		CommonResponse response=new CommonResponse();
		response.setData(jsonUsers);
		response.setCode(ResponseCode.SUCCESS.getCode());
		response.setMsg(ResponseCode.SUCCESS.getDesc());
		return response;
	}
	@Override
	public User save(User user) {
		return dao.save(user);	
	}
	@Override
	public User findOne(int id) {
		return dao.findOne(id);	
	}
	@Override
	public User deleteById(int id) {
		return dao.deleteById(id);
	}
}
