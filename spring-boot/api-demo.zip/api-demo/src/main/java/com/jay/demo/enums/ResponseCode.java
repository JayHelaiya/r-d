package com.jay.demo.enums;

public enum ResponseCode {
	
	// SUCCESS
	SUCCESS("000", "success","200","ok"),
	
	//ERROR
	RECORD_NOT_FOUND("ERR001", "record not found","404", "not found");
	
	
    private String code;
    private String desc;
    private String httpCode;
    private String httpDesc;
    
    
    
	private ResponseCode(String code, String desc, String httpCode, String httpDesc) {
		this.code = code;
		this.desc = desc;
		this.httpCode = httpCode;
		this.httpDesc = httpDesc;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getHttpCode() {
		return httpCode;
	}
	public void setHttpCode(String httpCode) {
		this.httpCode = httpCode;
	}
	public String getHttpDesc() {
		return httpDesc;
	}
	public void setHttpDesc(String httpDesc) {
		this.httpDesc = httpDesc;
	}
    
}
