package com.jay.demo.service;

import java.util.Optional;

import com.jay.demo.dao.model.Note;
import com.jay.demo.exceptions.ApException;
import com.jay.demo.response.CommonResponse;

public interface NoteService {

	public CommonResponse getAllNotes() throws ApException;

	public Note createNote(Note note);

	public Optional<Note> getNoteById(Long noteId);

	public void deleteNote(Note note);

}
