package com.jay.demo.exceptions;

/**
 * The MyBusinessException wraps all checked standard Java exception and enriches them with a custom error code.
 * You can use this code to retrieve localized error messages and to link to our online documentation.
 * 
 * @author TJanssen
 */
public class ApException extends Exception {

	private static final long serialVersionUID = 7718828512143293558L;
	
	private final String status;
	private final String code;
	

	public ApException(String code,String status) {
		super();
		this.code = code;
		this.status=status;
	}

	public ApException(String status,String message, Throwable cause, String code) {
		super(message, cause);
		this.code = code;
		this.status=status;
	}

	public ApException(String status,String message, String code) {
		super(message);
		this.code = code;
		this.status=status;
	}

	public ApException(String status,Throwable cause, String code) {
		super(cause);
		this.code = code;
		this.status=status;
	}
	
	public String getCode() {
		return this.code;
	}

	public String getStatus() {
		return status;
	}
	
}