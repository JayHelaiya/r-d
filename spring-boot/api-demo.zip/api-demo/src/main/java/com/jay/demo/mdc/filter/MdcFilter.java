package com.jay.demo.mdc.filter;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;

import com.jay.demo.constant.Constants;

@WebFilter("/api/v1/*")
public class MdcFilter implements Filter {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7396892941174027430L;

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		try {
			if (request instanceof HttpServletRequest) {

				HttpServletRequest httpRequest = (HttpServletRequest) request;
				String correlationId = getCorrelationIdFromHeader(httpRequest);
				MDC.put(Constants.CORRELATION_ID, correlationId);
				chain.doFilter(request, response);
			}
		} finally {
			MDC.remove(Constants.CORRELATION_ID);
		}
	}
	
	private String getCorrelationIdFromHeader(final HttpServletRequest request) {
		String correlationId = request.getHeader(Constants.CORRELATION_ID);
		if (StringUtils.isBlank(correlationId)) {
			correlationId = getCorrelationId();
		}
		return correlationId;
	}

	private String getCorrelationId() {
		return UUID.randomUUID().toString();
	}
}
