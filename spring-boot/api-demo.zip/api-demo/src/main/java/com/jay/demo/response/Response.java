package com.jay.demo.response;

import java.io.Serializable;

/**
 * This is marker interface for response model.
 * 
 *
 */
public interface Response extends Serializable {

}