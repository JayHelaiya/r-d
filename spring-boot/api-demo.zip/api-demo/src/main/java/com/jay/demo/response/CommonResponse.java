package com.jay.demo.response;


/**
 * @author Jayesh
 *
 *
 eg: response : {
	
	status : 404
	msg : member does not found
	Code : 101

}

response : {
	
	status : 200
	msg : success
	Code : 000
	data : {
		
		id : 10
		name : jayesh
		mobile : 60697979
	}

}
 */
public class CommonResponse implements Response{

	private static final long serialVersionUID = 6306225240617386613L;
	
	private int status;
	private String msg;
	private String code;
	private Object data;
	
	public CommonResponse() {}
	
	public CommonResponse(int status, String msg,String code) {
		super();
		this.status = status;
		this.msg = msg;
		this.code = code;
		
	}
	
	public CommonResponse(int status, String msg, String code,Object data) {
		super();
		this.status = status;
		this.msg = msg;
		this.code = code;
		this.data = data;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
}