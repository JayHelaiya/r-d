package com.jay.demo.constant;

public class Constants {
	 public static final String CORRELATION_ID = "correlationId";
}
