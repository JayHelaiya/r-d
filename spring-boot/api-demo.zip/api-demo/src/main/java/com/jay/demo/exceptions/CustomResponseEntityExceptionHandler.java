package com.jay.demo.exceptions;


import java.util.Date;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
@RestController
public class CustomResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@ExceptionHandler(ApException.class)
	public final ResponseEntity<Object> handleAllException
			(ApException ex, WebRequest request) throws ApException {
		String stackTrace = ExceptionUtils.getStackTrace(ex.getCause());
		HttpStatus httpStatus = getHttpCodeFromError(ex.getStatus());
		ExceptionResponse exceptionResponse=new ExceptionResponse(new Date(),String.valueOf(httpStatus.value()), httpStatus.getReasonPhrase(),ex.getCode(),ex.getMessage(),request.getDescription(false),ex.getCause().getMessage(),stackTrace);
		return new ResponseEntity(exceptionResponse, getHttpCodeFromError(ex.getStatus()));
	}
	
	private HttpStatus getHttpCodeFromError(String status) {
		for (HttpStatus htpCode : HttpStatus.values()) {
			if(String.valueOf(htpCode.value()).equalsIgnoreCase(status)) {
				return htpCode;
			}
		}
		return HttpStatus.INTERNAL_SERVER_ERROR;
	}
	
}
