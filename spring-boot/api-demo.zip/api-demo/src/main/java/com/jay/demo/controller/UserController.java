package com.jay.demo.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.jay.demo.dao.model.User;
import com.jay.demo.exceptions.ApException;
import com.jay.demo.exceptions.UserNotFoundException;
import com.jay.demo.response.CommonResponse;
import com.jay.demo.response.Response;
import com.jay.demo.service.UserService;


@RestController
public class UserController {
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);

	@Autowired
	UserService service;
	
	@GetMapping("/users")
	public @ResponseBody ResponseEntity<Response> getUsers() throws ApException {
		
		logger.info("msg for info");
		logger.error("msg for error");
		logger.warn("msg for warn");
		logger.trace("msg for trace");
		  CommonResponse response = service.findAll();
		  response.setStatus(HttpStatus.OK.value());
		  return new ResponseEntity<>(response,HttpStatus.OK);
	}
	
	
	@GetMapping("/users/{id}")
	public @ResponseBody ResponseEntity<User> getUser(@PathVariable int id) {
		 
		User user = service.findOne(id);
		if(user==null) {
			 throw new UserNotFoundException("id-"+id);
		 }
		 return new ResponseEntity<>(user,HttpStatus.OK);
	}
	
	
	@PostMapping("/users")
	public ResponseEntity<User> saveUser(@RequestBody User user) {
		
		user = service.save(user);
		
//		ControllerLinkBuilder linkTo = linkTo(methodOn(this.getClass()).getUser(user.getUserId()));
//		user.add(linkTo.withRel("user"));
//		 
//		HttpHeaders headers = new HttpHeaders();
//	        headers.setLocation(ucBuilder.path("/{id}").buildAndExpand(user.getUserId()).toUri());
//		
	        
	     return new ResponseEntity<>(user, HttpStatus.CREATED);
	}
	
	
	@DeleteMapping("/users/{id}")
	public ResponseEntity<User> deleteUser(@PathVariable int id) {
		User user = service.deleteById(id);
		if(user==null) {
			 throw new UserNotFoundException("id-"+id);
		 }
					
		 return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
}
