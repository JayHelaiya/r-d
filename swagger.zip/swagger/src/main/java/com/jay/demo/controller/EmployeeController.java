package com.jay.demo.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.jay.demo.dao.model.Employee;
import com.jay.demo.exceptions.ApException;
import com.jay.demo.exceptions.ResourceNotFoundException;
import com.jay.demo.response.CommonResponse;
import com.jay.demo.response.Response;
import com.jay.demo.service.NoteService;

/**
 * Created by jayesh helaiya
 */
@RestController
@RequestMapping("/api")
public class EmployeeController {

	@Autowired
	NoteService notService;

	@GetMapping("/v1/notes")
	public @ResponseBody ResponseEntity<Response> getAllNotes() throws ApException {
		
		
		CommonResponse response = notService.getAllNotes();
		response.setStatus(HttpStatus.OK.value());
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PostMapping("/v1/notes")
	public Employee createNote(@Valid @RequestBody Employee note) {
		return notService.createNote(note);
	}

	@GetMapping("/v1/notes/{id}")
	public Employee getNoteById(@PathVariable(value = "id") Long noteId) {
		return notService.getNoteById(noteId).orElseThrow(() -> new ResourceNotFoundException("Note", "id", noteId));
	}

	@PutMapping("/v1/notes/{id}")
	public Employee updateNote(@PathVariable(value = "id") Long noteId, @Valid @RequestBody Employee noteDetails) {

		Employee note = notService.getNoteById(noteId)
				.orElseThrow(() -> new ResourceNotFoundException("Note", "id", noteId));

		note.setTitle(noteDetails.getTitle());
		note.setContent(noteDetails.getContent());

		Employee updatedNote = notService.createNote(note);
		return updatedNote;
	}

	@DeleteMapping("/v1/notes/{id}")
	public ResponseEntity<?> deleteNote(@PathVariable(value = "id") Long noteId) {
		Employee note = notService.getNoteById(noteId)
				.orElseThrow(() -> new ResourceNotFoundException("Note", "id", noteId));

		notService.deleteNote(note);

		return ResponseEntity.ok().build();
	}
}
