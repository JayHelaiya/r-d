package com.jay.demo.service;

import com.jay.demo.dao.model.User;
import com.jay.demo.exceptions.ApException;
import com.jay.demo.response.CommonResponse;


public interface UserService {

	CommonResponse findAll() throws ApException;

	User save(User user);

	User findOne(int id);

	User deleteById(int id);
	

}
