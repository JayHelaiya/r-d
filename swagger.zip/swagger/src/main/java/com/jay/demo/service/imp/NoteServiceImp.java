package com.jay.demo.service.imp;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.jay.demo.controller.UserController;
import com.jay.demo.dao.NoteRepository;
import com.jay.demo.dao.model.Employee;
import com.jay.demo.dao.model.User;
import com.jay.demo.enums.ResponseCode;
import com.jay.demo.exceptions.ApException;
import com.jay.demo.response.CommonResponse;
import com.jay.demo.service.NoteService;
import com.jay.demo.util.JsonUtil;

@Service
public class NoteServiceImp implements NoteService{
	
	private static final Logger logger = LoggerFactory.getLogger(NoteServiceImp.class);

	@Autowired
	NoteRepository noteRepository;
	
	public CommonResponse getAllNotes() throws ApException{
		List<Employee> notes = noteRepository.findAll();
		
		try {
			  int a = 20/0; 

		}catch (Exception e) {
			logger.error("devide by 0 error", e);
			throw new ApException(ResponseCode.RECORD_NOT_FOUND.getHttpCode(),ResponseCode.RECORD_NOT_FOUND.getDesc(), e,ResponseCode.RECORD_NOT_FOUND.getCode());
		}
		
		if(notes==null) {
			throw new ApException(ResponseCode.RECORD_NOT_FOUND.getHttpCode(),ResponseCode.RECORD_NOT_FOUND.getDesc(), new NullPointerException(),ResponseCode.RECORD_NOT_FOUND.getCode());
		}
		@SuppressWarnings("unused")
		List<Employee> jsonUsers = JsonUtil.fromObject(notes, new TypeReference<List<Employee>>(){});
		CommonResponse response=new CommonResponse();
		response.setData(jsonUsers);
		response.setCode(ResponseCode.SUCCESS.getCode());
		response.setMsg(ResponseCode.SUCCESS.getDesc());
		return response;
	}

	public Employee createNote(Employee note) {
		 return noteRepository.save(note);
	}

	public Optional<Employee> getNoteById(Long noteId) {
		return noteRepository.findById(noteId);
	}


	public void deleteNote(Employee note) {
		 noteRepository.delete(note);
	}

}
