package com.jay.demo.exceptions;

import java.util.Date;

public class ExceptionResponse {
	
	
	private Date timestamp;
	private String status;
	private String error;
	private String code;
	private String message;
	private String path;
	private String cause;
	private String exception;
	
	
	
	public ExceptionResponse() {
		// TODO Auto-generated constructor stub
	}

	public ExceptionResponse(Date timestamp, String status, String error, String code, String message, String path,
			String cause, String exception) {
		super();
		this.timestamp = timestamp;
		this.status = status;
		this.error = error;
		this.code = code;
		this.message = message;
		this.path = path;
		this.cause = cause;
		this.exception = exception;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getCause() {
		return cause;
	}

	public void setCause(String cause) {
		this.cause = cause;
	}

	public String getException() {
		return exception;
	}

	public void setException(String exception) {
		this.exception = exception;
	}
	
}
